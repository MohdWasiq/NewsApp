# NewsApp
An iOS application having Just For You and News Section

* users can add news to the favourite section to read the news later
* favourite functionality is maintained among all modules
![Simulator Screen Shot - iPhone 12 mini - 2022-08-31 at 18 20 30](https://user-images.githubusercontent.com/81093987/187682413-9d2775cf-cde1-4008-aee8-1515249a74e0.png)
![Simulator Screen Shot - iPhone 12 mini - 2022-08-31 at 18 20 52](https://user-images.githubusercontent.com/81093987/187682492-f5030a34-0a7a-448a-b158-bd8b9946a914.png)
![Simulator Screen Shot - iPhone 12 mini - 2022-08-31 at 18 20 30](https://user-images.githubusercontent.com/81093987/187682513-e8116f08-cfa9-4b6e-8611-fc49d5fd6aa8.png)
